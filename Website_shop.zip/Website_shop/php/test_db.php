<?php
$serverName = "TUF\\vhord"; // Zmień na swoją nazwę serwera SQL
$connectionOptions = array(
    "Database" => "SklepDB",
    "Uid" => "sa", // Login MSSQL
    "PWD" => "TwojeHaslo" // Hasło do SQL Server
);

$conn = sqlsrv_connect($serverName, $connectionOptions);
if (!$conn) {
    die("❌ Błąd połączenia: " . print_r(sqlsrv_errors(), true));
} else {
    echo "✅ Połączenie z MSSQL działa!";
}
?>
