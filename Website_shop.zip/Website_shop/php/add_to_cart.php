<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = $_POST['product_id'];

    try {
        $stmt = $pdo->prepare("INSERT INTO Cart (product_id, quantity) VALUES (?, 1)
                               ON DUPLICATE KEY UPDATE quantity = quantity + 1");
        $stmt->execute([$product_id]);
        echo json_encode(["status" => "success"]);
    } catch (PDOException $e) {
        echo json_encode(["error" => $e->getMessage()]);
    }
}
?>
